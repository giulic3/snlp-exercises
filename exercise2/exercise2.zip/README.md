# Exercise Sheet 2

### Prerequisites

* Python 3.x

## Running 

In the unzipped folder, execute:

```
python3 main.py
```
